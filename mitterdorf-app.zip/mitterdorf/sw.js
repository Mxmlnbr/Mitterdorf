/* Service Worker: Grundgerüst offline halten, Daten immer frisch holen */
const CACHE = 'mitterdorf-v1';
const SCHALE = ['./', './index.html', './manifest.json', './icon.svg'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SCHALE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(k => Promise.all(k.filter(n => n !== CACHE).map(n => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;

  // daten.json: erst Netz, bei Ausfall der letzte bekannte Stand
  if (url.pathname.endsWith('daten.json')) {
    e.respondWith(
      fetch(e.request)
        .then(a => { const k = a.clone(); caches.open(CACHE).then(c => c.put(e.request, k)); return a; })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // Redaktion nie aus dem Cache
  if (url.pathname.endsWith('redaktion.html')) return;

  e.respondWith(caches.match(e.request).then(t => t || fetch(e.request)));
});
